﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mod_clientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mod_clientes))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxnomb = New System.Windows.Forms.TextBox()
        Me.TextBoxfech = New System.Windows.Forms.TextBox()
        Me.TextBoxnac = New System.Windows.Forms.TextBox()
        Me.TextBoxdom = New System.Windows.Forms.TextBox()
        Me.TextBoxci = New System.Windows.Forms.TextBox()
        Me.TextBoxcivil = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBoxpin = New System.Windows.Forms.TextBox()
        Me.Buttonok = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Labelsex = New System.Windows.Forms.Label()
        Me.TextBoxsex = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(603, 97)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(163, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha de Nacimiento:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(604, 205)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Domicilio:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(135, 97)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nombre:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(135, 206)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Nacionalidad:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(135, 305)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Sexo:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(604, 311)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "C.I:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(141, 424)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Estado Civil:"
        '
        'TextBoxnomb
        '
        Me.TextBoxnomb.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxnomb.Location = New System.Drawing.Point(138, 120)
        Me.TextBoxnomb.Name = "TextBoxnomb"
        Me.TextBoxnomb.Size = New System.Drawing.Size(143, 26)
        Me.TextBoxnomb.TabIndex = 2
        '
        'TextBoxfech
        '
        Me.TextBoxfech.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxfech.Location = New System.Drawing.Point(607, 120)
        Me.TextBoxfech.Name = "TextBoxfech"
        Me.TextBoxfech.Size = New System.Drawing.Size(145, 26)
        Me.TextBoxfech.TabIndex = 3
        '
        'TextBoxnac
        '
        Me.TextBoxnac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxnac.Location = New System.Drawing.Point(138, 228)
        Me.TextBoxnac.Name = "TextBoxnac"
        Me.TextBoxnac.Size = New System.Drawing.Size(143, 26)
        Me.TextBoxnac.TabIndex = 4
        '
        'TextBoxdom
        '
        Me.TextBoxdom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxdom.Location = New System.Drawing.Point(607, 228)
        Me.TextBoxdom.Name = "TextBoxdom"
        Me.TextBoxdom.Size = New System.Drawing.Size(145, 26)
        Me.TextBoxdom.TabIndex = 5
        '
        'TextBoxci
        '
        Me.TextBoxci.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxci.Location = New System.Drawing.Point(608, 334)
        Me.TextBoxci.Name = "TextBoxci"
        Me.TextBoxci.Size = New System.Drawing.Size(145, 26)
        Me.TextBoxci.TabIndex = 7
        '
        'TextBoxcivil
        '
        Me.TextBoxcivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxcivil.Location = New System.Drawing.Point(138, 447)
        Me.TextBoxcivil.Name = "TextBoxcivil"
        Me.TextBoxcivil.Size = New System.Drawing.Size(143, 26)
        Me.TextBoxcivil.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(199, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(191, 20)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Ingrese el PIN del Cliente:"
        '
        'TextBoxpin
        '
        Me.TextBoxpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxpin.Location = New System.Drawing.Point(410, 16)
        Me.TextBoxpin.Name = "TextBoxpin"
        Me.TextBoxpin.Size = New System.Drawing.Size(142, 26)
        Me.TextBoxpin.TabIndex = 0
        '
        'Buttonok
        '
        Me.Buttonok.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonok.Location = New System.Drawing.Point(583, 12)
        Me.Buttonok.Name = "Buttonok"
        Me.Buttonok.Size = New System.Drawing.Size(54, 35)
        Me.Buttonok.TabIndex = 1
        Me.Buttonok.Text = "OK"
        Me.Buttonok.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(369, 523)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(142, 20)
        Me.Label16.TabIndex = 24
        Me.Label16.Text = "¿Desea Modificar?"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(179, 568)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(137, 45)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Aceptar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(570, 568)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(137, 45)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Cancelar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Labelsex
        '
        Me.Labelsex.AutoSize = True
        Me.Labelsex.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelsex.Location = New System.Drawing.Point(199, 305)
        Me.Labelsex.Name = "Labelsex"
        Me.Labelsex.Size = New System.Drawing.Size(14, 20)
        Me.Labelsex.TabIndex = 28
        Me.Labelsex.Text = "-"
        '
        'TextBoxsex
        '
        Me.TextBoxsex.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxsex.Location = New System.Drawing.Point(138, 334)
        Me.TextBoxsex.Name = "TextBoxsex"
        Me.TextBoxsex.Size = New System.Drawing.Size(143, 26)
        Me.TextBoxsex.TabIndex = 6
        '
        'mod_clientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.TextBoxsex)
        Me.Controls.Add(Me.Labelsex)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Buttonok)
        Me.Controls.Add(Me.TextBoxpin)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBoxcivil)
        Me.Controls.Add(Me.TextBoxci)
        Me.Controls.Add(Me.TextBoxdom)
        Me.Controls.Add(Me.TextBoxnac)
        Me.Controls.Add(Me.TextBoxfech)
        Me.Controls.Add(Me.TextBoxnomb)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "mod_clientes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Modificación de Clientes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBoxnomb As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxfech As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxnac As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxdom As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxci As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxcivil As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBoxpin As System.Windows.Forms.TextBox
    Friend WithEvents Buttonok As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Labelsex As System.Windows.Forms.Label
    Friend WithEvents TextBoxsex As System.Windows.Forms.TextBox
End Class
