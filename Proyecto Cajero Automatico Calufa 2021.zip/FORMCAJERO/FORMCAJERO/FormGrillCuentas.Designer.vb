﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormGrillCuentas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormGrillCuentas))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Buttoncuentas = New System.Windows.Forms.Button()
        Me.Buttoncuentaspesos = New System.Windows.Forms.Button()
        Me.Buttoncuentasdolares = New System.Windows.Forms.Button()
        Me.Buttonahorropesos = New System.Windows.Forms.Button()
        Me.Buttonahorroendolares = New System.Windows.Forms.Button()
        Me.Buttoncrrienteenpesos = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ButtonSuc = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxSuc = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 30)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(860, 404)
        Me.DataGridView1.TabIndex = 0
        '
        'Buttoncuentas
        '
        Me.Buttoncuentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttoncuentas.Location = New System.Drawing.Point(12, 584)
        Me.Buttoncuentas.Name = "Buttoncuentas"
        Me.Buttoncuentas.Size = New System.Drawing.Size(125, 55)
        Me.Buttoncuentas.TabIndex = 4
        Me.Buttoncuentas.Text = "Todas las Cuentas"
        Me.Buttoncuentas.UseVisualStyleBackColor = True
        '
        'Buttoncuentaspesos
        '
        Me.Buttoncuentaspesos.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttoncuentaspesos.Location = New System.Drawing.Point(12, 466)
        Me.Buttoncuentaspesos.Name = "Buttoncuentaspesos"
        Me.Buttoncuentaspesos.Size = New System.Drawing.Size(125, 53)
        Me.Buttoncuentaspesos.TabIndex = 2
        Me.Buttoncuentaspesos.Text = "Cuentas en Pesos"
        Me.Buttoncuentaspesos.UseVisualStyleBackColor = True
        '
        'Buttoncuentasdolares
        '
        Me.Buttoncuentasdolares.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttoncuentasdolares.Location = New System.Drawing.Point(12, 526)
        Me.Buttoncuentasdolares.Name = "Buttoncuentasdolares"
        Me.Buttoncuentasdolares.Size = New System.Drawing.Size(125, 52)
        Me.Buttoncuentasdolares.TabIndex = 3
        Me.Buttoncuentasdolares.Text = "Cuentas en Dolares"
        Me.Buttoncuentasdolares.UseVisualStyleBackColor = True
        '
        'Buttonahorropesos
        '
        Me.Buttonahorropesos.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonahorropesos.Location = New System.Drawing.Point(163, 464)
        Me.Buttonahorropesos.Name = "Buttonahorropesos"
        Me.Buttonahorropesos.Size = New System.Drawing.Size(160, 55)
        Me.Buttonahorropesos.TabIndex = 5
        Me.Buttonahorropesos.Text = "Caja de Ahorros en Pesos"
        Me.Buttonahorropesos.UseVisualStyleBackColor = True
        '
        'Buttonahorroendolares
        '
        Me.Buttonahorroendolares.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonahorroendolares.Location = New System.Drawing.Point(163, 525)
        Me.Buttonahorroendolares.Name = "Buttonahorroendolares"
        Me.Buttonahorroendolares.Size = New System.Drawing.Size(160, 53)
        Me.Buttonahorroendolares.TabIndex = 6
        Me.Buttonahorroendolares.Text = "Caja de Ahorros en Dolares"
        Me.Buttonahorroendolares.UseVisualStyleBackColor = True
        '
        'Buttoncrrienteenpesos
        '
        Me.Buttoncrrienteenpesos.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttoncrrienteenpesos.Location = New System.Drawing.Point(348, 464)
        Me.Buttoncrrienteenpesos.Name = "Buttoncrrienteenpesos"
        Me.Buttoncrrienteenpesos.Size = New System.Drawing.Size(160, 55)
        Me.Buttoncrrienteenpesos.TabIndex = 8
        Me.Buttoncrrienteenpesos.Text = "Cuenta Corriente en Pesos"
        Me.Buttoncrrienteenpesos.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(348, 525)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 53)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Cuenta Corriente en Dolares"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(527, 464)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(167, 55)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Dolares Mayor a U$D 10.000"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(163, 584)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(160, 52)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "U$D 2018"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ButtonSuc
        '
        Me.ButtonSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSuc.Location = New System.Drawing.Point(747, 592)
        Me.ButtonSuc.Name = "ButtonSuc"
        Me.ButtonSuc.Size = New System.Drawing.Size(60, 36)
        Me.ButtonSuc.TabIndex = 1
        Me.ButtonSuc.Text = "OK"
        Me.ButtonSuc.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(611, 558)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 20)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Ingrese Nº de Sucursal"
        '
        'TextBoxSuc
        '
        Me.TextBoxSuc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSuc.Location = New System.Drawing.Point(594, 598)
        Me.TextBoxSuc.Name = "TextBoxSuc"
        Me.TextBoxSuc.Size = New System.Drawing.Size(147, 26)
        Me.TextBoxSuc.TabIndex = 0
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(348, 584)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(160, 52)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "$ 2019"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'FormGrillCuentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.TextBoxSuc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ButtonSuc)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Buttoncrrienteenpesos)
        Me.Controls.Add(Me.Buttonahorroendolares)
        Me.Controls.Add(Me.Buttonahorropesos)
        Me.Controls.Add(Me.Buttoncuentasdolares)
        Me.Controls.Add(Me.Buttoncuentaspesos)
        Me.Controls.Add(Me.Buttoncuentas)
        Me.Controls.Add(Me.DataGridView1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormGrillCuentas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Consultas"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Buttoncuentas As System.Windows.Forms.Button
    Friend WithEvents Buttoncuentaspesos As System.Windows.Forms.Button
    Friend WithEvents Buttoncuentasdolares As System.Windows.Forms.Button
    Friend WithEvents Buttonahorropesos As System.Windows.Forms.Button
    Friend WithEvents Buttonahorroendolares As System.Windows.Forms.Button
    Friend WithEvents Buttoncrrienteenpesos As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ButtonSuc As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxSuc As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
End Class
