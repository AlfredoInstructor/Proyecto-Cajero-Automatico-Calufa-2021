﻿Public Class FormMantSucursal

    Private Sub Buttonaltsucursal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonaltsucursal.Click
        FormAltaSucursal.ShowDialog()
    End Sub

    Private Sub Buttonbajasucursal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonbajasucursal.Click
        FormBajaSucursal.ShowDialog()
    End Sub

    Private Sub Buttonmodsucursal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonmodsucursal.Click
        FormModSucursal.ShowDialog()
    End Sub
End Class