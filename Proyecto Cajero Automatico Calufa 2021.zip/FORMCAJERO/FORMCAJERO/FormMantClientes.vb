﻿Imports MySql.Data.MySqlClient
Public Class Mantenimiento_Clientes

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clientes_altas.Click
        alta_clientes.ShowDialog()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clientes_baja.Click
        baja_clientes.ShowDialog()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cliente_mod.Click
        mod_clientes.ShowDialog()
    End Sub

    Private Sub Mantenimiento_Clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class