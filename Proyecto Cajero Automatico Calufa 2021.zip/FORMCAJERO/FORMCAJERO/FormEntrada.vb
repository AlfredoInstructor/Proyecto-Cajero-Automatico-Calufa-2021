﻿Imports MySql.Data.MySqlClient
Public Class FormEntrada

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        Try
            oConexion.Open()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        FormPrincipal.ShowDialog()
    End Sub
    Private Sub ToolTip1_Popup(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PopupEventArgs)


    End Sub

    Private Sub FormEntrada_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Tip()
    End Sub
    Sub Tip()
        ToolTip1.SetToolTip(PictureBox1, "Presione Aqui")
    End Sub
End Class