﻿Imports MySql.Data.MySqlClient
Module ModuleConexion

    Public cadena As String = "server=facundo-pc;port=3306;user id=prueba;password=1234;database=new_schema_proyecto"
    Public oConexion As New MySqlConnection(cadena)




End Module
