﻿Imports MySql.Data.MySqlClient
Public Class baja_cuentas

    Private Sub baja_cuentas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label7.Text = ""
        Label8.Text = ""
        Label9.Text = ""
        Label10.Text = ""
        Label11.Text = ""
        TextBoxpin.Text = ""
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label12.Click

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncancelar.Click
        Me.Close()
    End Sub

    Private Sub Buttonaceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonaceptar.Click
        Dim oSql As String = "DELETE FROM cuentas WHERE PIN = " & TextBoxpin.Text
        ' si fuera Varchar la union seria : " & "' TextBox1.Text "'
        Dim oCommand As New MySqlCommand(oSql, oConexion)
        Try
            oCommand.ExecuteNonQuery()
            MsgBox("Baja con Éxito")
            Me.Close()
        Catch ex As Exception
            MsgBox("ERROR" & ex.Message)
        End Try
    End Sub

    Private Sub Buttonok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM cuentas WHERE PIN = " & TextBoxpin.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then


            SQL = "SELECT Tipo_Cuenta, Moneda, Saldo, Fecha_Apertura, N_Sucursal FROM cuentas WHERE PIN = " & TextBoxpin.Text
            Com = New MySqlCommand(SQL, oConexion)

            Rs = Com.ExecuteReader()

            Rs.Read()

            Label7.Text = Rs(0)
            Label8.Text = Rs(1)
            Label9.Text = Rs(2)
            Label10.Text = Rs(3)
            Label11.Text = Rs(4)

            Rs.Close()
        Else
            MsgBox("PIN Incorrecto")
        End If


    End Sub
End Class