﻿Imports MySql.Data.MySqlClient
Public Class alta_cuentas

    Private Sub alta_cuentas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxpin.Text = ""
        ComboBoxtipocuenta.SelectedIndex = -1
        ComboBoxtipomoneda.SelectedIndex = -1
        TextBoxsaldo.Text = ""
        TextBoxapertura.Text = ""
        TextBoxsucursal.Text = ""



    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxpin.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oSql As String = "INSERT INTO cuentas(PIN, Tipo_Cuenta, Moneda, Saldo, Fecha_Apertura, N_Sucursal ) VALUES (" & TextBoxpin.Text & ", '" & ComboBoxtipocuenta.SelectedItem & "', '" & ComboBoxtipomoneda.SelectedItem & "', '" & TextBoxsaldo.Text & "', '" & TextBoxapertura.Text & "', " & TextBoxsucursal.Text & ")"
        Dim oComando As New MySqlCommand(oSql, oConexion)

        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class