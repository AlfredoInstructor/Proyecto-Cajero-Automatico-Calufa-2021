﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMantTransacciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMantTransacciones))
        Me.Buttonalt_transaccione = New System.Windows.Forms.Button()
        Me.Buttonbajatrans = New System.Windows.Forms.Button()
        Me.Buttonmodtrans = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Buttonalt_transaccione
        '
        Me.Buttonalt_transaccione.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonalt_transaccione.Location = New System.Drawing.Point(359, 95)
        Me.Buttonalt_transaccione.Name = "Buttonalt_transaccione"
        Me.Buttonalt_transaccione.Size = New System.Drawing.Size(242, 71)
        Me.Buttonalt_transaccione.TabIndex = 0
        Me.Buttonalt_transaccione.Text = "Alta de Transacciones"
        Me.Buttonalt_transaccione.UseVisualStyleBackColor = True
        '
        'Buttonbajatrans
        '
        Me.Buttonbajatrans.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonbajatrans.Location = New System.Drawing.Point(359, 270)
        Me.Buttonbajatrans.Name = "Buttonbajatrans"
        Me.Buttonbajatrans.Size = New System.Drawing.Size(242, 71)
        Me.Buttonbajatrans.TabIndex = 1
        Me.Buttonbajatrans.Text = "Baja de Transacciones"
        Me.Buttonbajatrans.UseVisualStyleBackColor = True
        '
        'Buttonmodtrans
        '
        Me.Buttonmodtrans.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonmodtrans.Location = New System.Drawing.Point(359, 464)
        Me.Buttonmodtrans.Name = "Buttonmodtrans"
        Me.Buttonmodtrans.Size = New System.Drawing.Size(242, 71)
        Me.Buttonmodtrans.TabIndex = 2
        Me.Buttonmodtrans.Text = "Modificación de Transacciones"
        Me.Buttonmodtrans.UseVisualStyleBackColor = True
        '
        'FormMantTransacciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.Buttonmodtrans)
        Me.Controls.Add(Me.Buttonbajatrans)
        Me.Controls.Add(Me.Buttonalt_transaccione)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMantTransacciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimieto de Transacciones"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Buttonalt_transaccione As System.Windows.Forms.Button
    Friend WithEvents Buttonbajatrans As System.Windows.Forms.Button
    Friend WithEvents Buttonmodtrans As System.Windows.Forms.Button
End Class
