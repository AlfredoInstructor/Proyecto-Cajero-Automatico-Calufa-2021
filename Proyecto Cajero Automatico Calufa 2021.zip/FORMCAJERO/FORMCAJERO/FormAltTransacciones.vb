﻿Imports MySql.Data.MySqlClient
Public Class FormAltTransacciones

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxhora.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oSql As String = "INSERT INTO transacciones(PIN, N_Transaccion, Fecha, Hora, Tipo_Transaccion) VALUES (" & TextBoxpin.Text & ", " & TextBoxnumtrans.Text & ", '" & TextBoxfecha.Text & "', '" & TextBoxhora.Text & "', '" & ComboBoxtipotrans.SelectedItem & "')"
        Dim oComando As New MySqlCommand(oSql, oConexion)

        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            oComando.ExecuteNonQuery()
            Me.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub FormAltTransacciones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxpin.Text = ""
        TextBoxnumtrans.Text = ""
        TextBoxfecha.Text = ""
        TextBoxhora.Text = ""
        ComboBoxtipotrans.SelectedIndex = -1

    End Sub
End Class