﻿Imports MySql.Data.MySqlClient
Public Class mod_clientes

    Private Sub mod_clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxnomb.Text = ""
        TextBoxfech.Text = ""
        TextBoxnac.Text = ""
        TextBoxdom.Text = ""
        TextBoxsex.Text = ""
        TextBoxci.Text = ""
        TextBoxcivil.Text = ""
        TextBoxpin.Text = ""
    End Sub

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label16.Click

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Buttonok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM clientes WHERE PIN = " & TextBoxpin.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then

            SQL = "SELECT Nombre, Fech_Nacimiento, Domicilio, Nacionalidad, Sexo, Cedula, Estado_Civil   FROM clientes WHERE PIN = " & TextBoxpin.Text
            Com = New MySqlCommand(SQL, oConexion)


            Rs = Com.ExecuteReader()

            Rs.Read()

            TextBoxnomb.Text = Rs(0)
            TextBoxfech.Text = Rs(1)
            TextBoxnac.Text = Rs(3)
            TextBoxdom.Text = Rs(2)
            TextBoxsex.Text = Rs(4)
            TextBoxci.Text = Rs(5)
            TextBoxcivil.Text = Rs(6)

            Rs.Close()

        Else
            MsgBox("PIN Incorrecto")
        End If

    End Sub

    Private Sub Label12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oSql As String = "UPDATE clientes SET Nombre = '" & TextBoxnomb.Text & "', " & " Fech_Nacimiento = '" & TextBoxfech.Text & "'," & " Domicilio = '" & TextBoxdom.Text & "', " & " Nacionalidad = '" & TextBoxnac.Text & "', " & " Sexo = '" & TextBoxsex.Text & "'," & " Cedula = " & TextBoxci.Text & "," & " Estado_Civil = '" & TextBoxcivil.Text & "' " & "WHERE PIN = " & TextBoxpin.Text
        Dim oComando As New MySqlCommand(oSql, oConexion)
        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()


        Catch ex As Exception
            MsgBox("Ocurrio el error:" & ex.Message)

        End Try

    End Sub

    Private Sub Labelsex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Labelsex.Click

    End Sub
End Class