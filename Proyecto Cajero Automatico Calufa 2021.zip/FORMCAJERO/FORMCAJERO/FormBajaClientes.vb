﻿Imports MySql.Data.MySqlClient
Public Class baja_clientes

    Private Sub baja_clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label9.Text = ""
        Label10.Text = ""
        Label11.Text = ""
        Label12.Text = ""
        Label13.Text = ""
        Label14.Text = ""
        Label15.Text = ""
        TextBoxpin.Text = ""

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oSql As String = "DELETE FROM clientes WHERE PIN = " & TextBoxpin.Text
        ' si fuera Varchar la union seria : " & "' TextBox1.Text "'
        Dim oCommand As New MySqlCommand(oSql, oConexion)
        Try
            oCommand.ExecuteNonQuery()
            MsgBox("Baja con Éxito")
            Me.Close()
        Catch ex As Exception
            MsgBox("ERROR" & ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM clientes WHERE PIN = " & TextBoxpin.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then

            SQL = "SELECT Nombre, Fech_Nacimiento, Domicilio, Nacionalidad, Sexo, Cedula, Estado_Civil   FROM clientes WHERE PIN = " & TextBoxpin.Text
            Com = New MySqlCommand(SQL, oConexion)

            Rs = Com.ExecuteReader()

            Rs.Read()

            Label9.Text = Rs(0)
            Label10.Text = Rs(1)
            Label11.Text = Rs(2)
            Label12.Text = Rs(3)
            Label13.Text = Rs(4)
            Label14.Text = Rs(5)
            Label15.Text = Rs(6)

            Rs.Close()
        Else
            MsgBox("PIN Incorrecto")
        End If
    End Sub

    Private Sub Label14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label14.Click

    End Sub
End Class