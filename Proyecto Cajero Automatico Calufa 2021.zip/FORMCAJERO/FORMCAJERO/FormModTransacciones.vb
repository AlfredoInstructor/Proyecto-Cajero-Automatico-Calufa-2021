﻿Imports MySql.Data.MySqlClient
Public Class FormModTransacciones

    Private Sub FormModTransacciones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBoxtipotrans.SelectedIndex = -1
        TextBoxfech.Text = ""
        TextBoxhora.Text = ""
        TextBoxnumtrans.Text = ""
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Buttonok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM transacciones WHERE N_Transaccion = " & TextBoxnumtrans.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then


            SQL = "SELECT Tipo_Transaccion, Fecha, Hora FROM transacciones WHERE N_Transaccion = " & TextBoxnumtrans.Text
            Com = New MySqlCommand(SQL, oConexion)

            Rs = Com.ExecuteReader()

            Rs.Read()
            ComboBoxtipotrans.SelectedItem = Rs(0)
            TextBoxfech.Text = Rs(1)
            TextBoxhora.Text = Rs(2)

            Rs.Close()
        Else
            MsgBox("Nº de Transaccion Incorrecta")
        End If

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oSql As String = "UPDATE transacciones SET Tipo_Transaccion = '" & ComboBoxtipotrans.SelectedItem & "', " & " Fecha = '" & TextBoxfech.Text & "'," & " Hora = '" & TextBoxhora.Text & "' " & " WHERE N_Transaccion = " & TextBoxnumtrans.Text
        Dim oComando As New MySqlCommand(oSql, oConexion)
        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()


        Catch ex As Exception
            MsgBox("Ocurrio el error:" & ex.Message)

        End Try
    End Sub
End Class