﻿Imports MySql.Data.MySqlClient
Public Class FormAltaSucursal

    Private Sub Buttoningresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoningresar.Click
        Dim oSql As String = "INSERT INTO sucursales(N_Sucursal, Nombre_Sucursal, Direccion_Sucursal) VALUES (" & TextBoxnumsuc.Text & ", '" & TextBoxnombresuc.Text & "', '" & TextBoxdirsuc.Text & "')"
        Dim oComando As New MySqlCommand(oSql, oConexion)
        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()

            
        Catch ex As Exception
            MsgBox("Ocurrio el error:" & ex.Message)

        End Try
        Me.Close()
    End Sub

    Private Sub FormAltaSucursal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxnombresuc.Text = ""
        TextBoxdirsuc.Text = ""
        TextBoxnumsuc.Text = ""

    End Sub
End Class