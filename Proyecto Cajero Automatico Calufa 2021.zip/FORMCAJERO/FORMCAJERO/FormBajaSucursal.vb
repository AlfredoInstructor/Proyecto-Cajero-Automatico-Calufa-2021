﻿Imports MySql.Data.MySqlClient
Public Class FormBajaSucursal

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM sucursales WHERE N_Sucursal = " & TextBoxNumSuc.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then

            SQL = "SELECT N_Sucursal, Nombre_Sucursal, Direccion_Sucursal FROM sucursales WHERE N_Sucursal = " & TextBoxNumSuc.Text
            Com = New MySqlCommand(SQL, oConexion)

            Rs = Com.ExecuteReader()

            Rs.Read()
            Label3.Text = Rs(0)
            Label5.Text = Rs(1)
            Label7.Text = Rs(2)
            Rs.Close()
        Else
            MsgBox("El Nº de Sucursal es Incorrecto")
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oSql As String = "DELETE FROM sucursales WHERE N_Sucursal = " & TextBoxNumSuc.Text
        ' si fuera Varchar la union seria : " & "' TextBox1.Text "'
        Dim oCommand As New MySqlCommand(oSql, oConexion)
        Try
            oCommand.ExecuteNonQuery()
            MsgBox("Baja con Éxito")
            Me.Close()
        Catch ex As Exception
            MsgBox("ERROR" & ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub TextBoxNumSuc_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBoxNumSuc.TextChanged

    End Sub

    Private Sub FormBajaSucursal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label3.Text = ""
        Label5.Text = ""
        Label7.Text = ""
        TextBoxNumSuc.Text = ""
    End Sub
End Class