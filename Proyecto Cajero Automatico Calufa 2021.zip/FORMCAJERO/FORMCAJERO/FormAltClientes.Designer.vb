﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class alta_clientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(alta_clientes))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBoxpin = New System.Windows.Forms.TextBox()
        Me.TextBoxci = New System.Windows.Forms.TextBox()
        Me.TextBoxnombre = New System.Windows.Forms.TextBox()
        Me.TextBoxdomicilio = New System.Windows.Forms.TextBox()
        Me.TextBoxnacimiento = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBoxcivil = New System.Windows.Forms.ComboBox()
        Me.ComboBoxnac = New System.Windows.Forms.ComboBox()
        Me.ComboBoxsex = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(248, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PIN: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(248, 356)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(159, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Fecha de Nacimiento"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(248, 303)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Domicilio:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(248, 246)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Nombre:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(248, 418)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Nacionalidad:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(248, 470)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Sexo:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(248, 124)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "C.I:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(248, 182)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Estado Civil:"
        '
        'TextBoxpin
        '
        Me.TextBoxpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxpin.Location = New System.Drawing.Point(472, 64)
        Me.TextBoxpin.Name = "TextBoxpin"
        Me.TextBoxpin.Size = New System.Drawing.Size(181, 26)
        Me.TextBoxpin.TabIndex = 0
        '
        'TextBoxci
        '
        Me.TextBoxci.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxci.Location = New System.Drawing.Point(472, 118)
        Me.TextBoxci.Name = "TextBoxci"
        Me.TextBoxci.Size = New System.Drawing.Size(181, 26)
        Me.TextBoxci.TabIndex = 1
        '
        'TextBoxnombre
        '
        Me.TextBoxnombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxnombre.Location = New System.Drawing.Point(472, 240)
        Me.TextBoxnombre.Name = "TextBoxnombre"
        Me.TextBoxnombre.Size = New System.Drawing.Size(181, 26)
        Me.TextBoxnombre.TabIndex = 3
        '
        'TextBoxdomicilio
        '
        Me.TextBoxdomicilio.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxdomicilio.Location = New System.Drawing.Point(472, 297)
        Me.TextBoxdomicilio.Name = "TextBoxdomicilio"
        Me.TextBoxdomicilio.Size = New System.Drawing.Size(181, 26)
        Me.TextBoxdomicilio.TabIndex = 4
        '
        'TextBoxnacimiento
        '
        Me.TextBoxnacimiento.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxnacimiento.Location = New System.Drawing.Point(472, 353)
        Me.TextBoxnacimiento.Name = "TextBoxnacimiento"
        Me.TextBoxnacimiento.Size = New System.Drawing.Size(181, 26)
        Me.TextBoxnacimiento.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(365, 563)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(177, 55)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Ingresar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBoxcivil
        '
        Me.ComboBoxcivil.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxcivil.FormattingEnabled = True
        Me.ComboBoxcivil.Items.AddRange(New Object() {"Soltero/a", "Casado/a", "Viudo/a"})
        Me.ComboBoxcivil.Location = New System.Drawing.Point(472, 174)
        Me.ComboBoxcivil.Name = "ComboBoxcivil"
        Me.ComboBoxcivil.Size = New System.Drawing.Size(181, 28)
        Me.ComboBoxcivil.TabIndex = 2
        '
        'ComboBoxnac
        '
        Me.ComboBoxnac.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxnac.FormattingEnabled = True
        Me.ComboBoxnac.Items.AddRange(New Object() {"Uruguayo", "Brasileño"})
        Me.ComboBoxnac.Location = New System.Drawing.Point(472, 410)
        Me.ComboBoxnac.Name = "ComboBoxnac"
        Me.ComboBoxnac.Size = New System.Drawing.Size(181, 28)
        Me.ComboBoxnac.TabIndex = 6
        '
        'ComboBoxsex
        '
        Me.ComboBoxsex.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxsex.FormattingEnabled = True
        Me.ComboBoxsex.Items.AddRange(New Object() {"Masculino", "Femenino"})
        Me.ComboBoxsex.Location = New System.Drawing.Point(472, 462)
        Me.ComboBoxsex.Name = "ComboBoxsex"
        Me.ComboBoxsex.Size = New System.Drawing.Size(181, 28)
        Me.ComboBoxsex.TabIndex = 7
        '
        'alta_clientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.ComboBoxsex)
        Me.Controls.Add(Me.ComboBoxnac)
        Me.Controls.Add(Me.ComboBoxcivil)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBoxnacimiento)
        Me.Controls.Add(Me.TextBoxdomicilio)
        Me.Controls.Add(Me.TextBoxnombre)
        Me.Controls.Add(Me.TextBoxci)
        Me.Controls.Add(Me.TextBoxpin)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "alta_clientes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Alta de Clientes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBoxpin As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxci As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxnombre As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxdomicilio As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxnacimiento As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboBoxcivil As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxnac As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxsex As System.Windows.Forms.ComboBox
End Class
