﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class alta_cuentas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(alta_cuentas))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBoxpin = New System.Windows.Forms.TextBox()
        Me.TextBoxsaldo = New System.Windows.Forms.TextBox()
        Me.TextBoxapertura = New System.Windows.Forms.TextBox()
        Me.TextBoxsucursal = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBoxtipocuenta = New System.Windows.Forms.ComboBox()
        Me.ComboBoxtipomoneda = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(210, 90)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PIN:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(210, 157)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tipo de Cuenta:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(210, 236)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Tipo de Moneda:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(210, 310)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Saldo:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(210, 377)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(146, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Fecha de Apertura:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(210, 444)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(157, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Numero de Sucursal:"
        '
        'TextBoxpin
        '
        Me.TextBoxpin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxpin.Location = New System.Drawing.Point(474, 84)
        Me.TextBoxpin.Name = "TextBoxpin"
        Me.TextBoxpin.Size = New System.Drawing.Size(188, 26)
        Me.TextBoxpin.TabIndex = 0
        '
        'TextBoxsaldo
        '
        Me.TextBoxsaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxsaldo.Location = New System.Drawing.Point(474, 304)
        Me.TextBoxsaldo.Name = "TextBoxsaldo"
        Me.TextBoxsaldo.Size = New System.Drawing.Size(188, 26)
        Me.TextBoxsaldo.TabIndex = 3
        '
        'TextBoxapertura
        '
        Me.TextBoxapertura.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxapertura.Location = New System.Drawing.Point(474, 374)
        Me.TextBoxapertura.Name = "TextBoxapertura"
        Me.TextBoxapertura.Size = New System.Drawing.Size(188, 26)
        Me.TextBoxapertura.TabIndex = 4
        '
        'TextBoxsucursal
        '
        Me.TextBoxsucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxsucursal.Location = New System.Drawing.Point(474, 438)
        Me.TextBoxsucursal.Name = "TextBoxsucursal"
        Me.TextBoxsucursal.Size = New System.Drawing.Size(188, 26)
        Me.TextBoxsucursal.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(351, 565)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(168, 58)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Ingresar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBoxtipocuenta
        '
        Me.ComboBoxtipocuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxtipocuenta.FormattingEnabled = True
        Me.ComboBoxtipocuenta.Items.AddRange(New Object() {"Corriente", "Ahorro"})
        Me.ComboBoxtipocuenta.Location = New System.Drawing.Point(474, 149)
        Me.ComboBoxtipocuenta.Name = "ComboBoxtipocuenta"
        Me.ComboBoxtipocuenta.Size = New System.Drawing.Size(188, 28)
        Me.ComboBoxtipocuenta.TabIndex = 1
        '
        'ComboBoxtipomoneda
        '
        Me.ComboBoxtipomoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxtipomoneda.FormattingEnabled = True
        Me.ComboBoxtipomoneda.Items.AddRange(New Object() {"Pesos UY", "Dolares"})
        Me.ComboBoxtipomoneda.Location = New System.Drawing.Point(474, 228)
        Me.ComboBoxtipomoneda.Name = "ComboBoxtipomoneda"
        Me.ComboBoxtipomoneda.Size = New System.Drawing.Size(188, 28)
        Me.ComboBoxtipomoneda.TabIndex = 2
        '
        'alta_cuentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.ComboBoxtipomoneda)
        Me.Controls.Add(Me.ComboBoxtipocuenta)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBoxsucursal)
        Me.Controls.Add(Me.TextBoxapertura)
        Me.Controls.Add(Me.TextBoxsaldo)
        Me.Controls.Add(Me.TextBoxpin)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "alta_cuentas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Alta de Cuentas"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBoxpin As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxsaldo As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxapertura As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxsucursal As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboBoxtipocuenta As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxtipomoneda As System.Windows.Forms.ComboBox
End Class
