﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formATM
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formATM))
        Me.retiro = New System.Windows.Forms.Button()
        Me.saldo = New System.Windows.Forms.Button()
        Me.deposito = New System.Windows.Forms.Button()
        Me.pin = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Buttonsalir = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'retiro
        '
        Me.retiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.retiro.Location = New System.Drawing.Point(677, 399)
        Me.retiro.Name = "retiro"
        Me.retiro.Size = New System.Drawing.Size(207, 68)
        Me.retiro.TabIndex = 3
        Me.retiro.Text = "Retiro"
        Me.retiro.UseVisualStyleBackColor = True
        '
        'saldo
        '
        Me.saldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.saldo.Location = New System.Drawing.Point(677, 183)
        Me.saldo.Name = "saldo"
        Me.saldo.Size = New System.Drawing.Size(207, 68)
        Me.saldo.TabIndex = 1
        Me.saldo.Text = "Saldo"
        Me.saldo.UseVisualStyleBackColor = True
        '
        'deposito
        '
        Me.deposito.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deposito.Location = New System.Drawing.Point(1, 399)
        Me.deposito.Name = "deposito"
        Me.deposito.Size = New System.Drawing.Size(207, 68)
        Me.deposito.TabIndex = 2
        Me.deposito.Text = "Depósito"
        Me.deposito.UseVisualStyleBackColor = True
        '
        'pin
        '
        Me.pin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pin.Location = New System.Drawing.Point(1, 183)
        Me.pin.Name = "pin"
        Me.pin.Size = New System.Drawing.Size(207, 68)
        Me.pin.TabIndex = 0
        Me.pin.Text = "Ingrese su PIN"
        Me.pin.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Castellar", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(558, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 33)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "5000"
        '
        'Buttonsalir
        '
        Me.Buttonsalir.BackColor = System.Drawing.Color.Red
        Me.Buttonsalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonsalir.ForeColor = System.Drawing.Color.White
        Me.Buttonsalir.Location = New System.Drawing.Point(360, 614)
        Me.Buttonsalir.Name = "Buttonsalir"
        Me.Buttonsalir.Size = New System.Drawing.Size(157, 70)
        Me.Buttonsalir.TabIndex = 5
        Me.Buttonsalir.Text = "SALIR"
        Me.Buttonsalir.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Castellar", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(281, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(309, 33)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Saldo Disponible"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Castellar", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(396, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(156, 33)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Dolares"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Castellar", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(197, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(193, 33)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Corriente"
        '
        'formATM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Buttonsalir)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pin)
        Me.Controls.Add(Me.deposito)
        Me.Controls.Add(Me.saldo)
        Me.Controls.Add(Me.retiro)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formATM"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cajero ATM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents retiro As System.Windows.Forms.Button
    Friend WithEvents saldo As System.Windows.Forms.Button
    Friend WithEvents deposito As System.Windows.Forms.Button
    Friend WithEvents pin As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Buttonsalir As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
