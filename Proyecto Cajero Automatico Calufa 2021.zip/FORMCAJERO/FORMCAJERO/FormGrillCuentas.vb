﻿Imports MySql.Data.MySqlClient
Public Class FormGrillCuentas

    Private Sub Buttoncuentas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncuentas.Click

        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try



    End Sub

    Private Sub Buttoncuentaspesos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncuentaspesos.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Moneda = 'Pesos' "

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try

    End Sub

    Private Sub Buttoncuentasdolares_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncuentasdolares.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Moneda = 'Dolares' "

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub

    Private Sub Buttonahorropesos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonahorropesos.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Tipo_Cuenta = 'Ahorro' AND Moneda = 'Pesos'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try

    End Sub

    Private Sub FormGrillCuentas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = ""
        TextBoxSuc.Text = ""
    End Sub

    Private Sub Buttonahorroendolares_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonahorroendolares.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Tipo_Cuenta = 'Ahorro' AND Moneda = 'Dolares'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try

    End Sub

    Private Sub Buttoncrrienteenpesos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttoncrrienteenpesos.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Tipo_Cuenta = 'Corriente' AND Moneda = 'Pesos'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Tipo_Cuenta = 'Corriente' AND Moneda = 'Dolares'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT PIN, Tipo_Cuenta, Moneda, Saldo, Fecha_Apertura, N_Sucursal FROM cuentas WHERE Saldo >= 10000 AND Moneda = 'Dolares'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub

    Private Sub ButtonSuc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSuc.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String
        oConexion.Open()

        SQL2 = "SELECT COUNT(*) FROM cuentas WHERE N_Sucursal = " & TextBoxSuc.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)


        Rs2.Close()

        If existe <> "0" Then

            Dim oSql As String = "SELECT * FROM cuentas WHERE N_Sucursal = " & TextBoxSuc.Text
            Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
            Dim dbdataset As New DataTable
            Try


                oAdapter.Fill(dbdataset)
                DataGridView1.DataSource = dbdataset

                oAdapter.Update(dbdataset)
            Catch ex As Exception
                MsgBox("Error" & ex.Message)
            End Try
        Else
            MsgBox("Nº de Sucursal Incorrecto")

        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT * FROM cuentas WHERE Fecha_Apertura BETWEEN '2018-01-01' AND '2018-12-31'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim oConexion As New MySqlConnection(cadena)
        Dim oSql As String = "SELECT PIN, Tipo_Cuenta, Moneda, Saldo, Fecha_Apertura, N_Sucursal FROM cuentas WHERE Saldo >= 100000 AND Moneda = 'Pesos' AND Fecha_Apertura BETWEEN '2019-01-03' AND '2019-03-31'"

        Dim oAdapter As New MySqlDataAdapter(oSql, oConexion)
        Dim dbdataset As New DataTable
        Try
            oConexion.Open()

            oAdapter.Fill(dbdataset)
            DataGridView1.DataSource = dbdataset

            oAdapter.Update(dbdataset)
        Catch ex As Exception
            MsgBox("Error" & ex.Message)

        End Try
    End Sub
End Class