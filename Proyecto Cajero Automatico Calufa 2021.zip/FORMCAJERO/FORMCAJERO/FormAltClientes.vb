﻿Imports MySql.Data.MySqlClient
Public Class alta_clientes

    Private Sub alta_clientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxpin.Text = ""
        TextBoxci.Text = ""
        ComboBoxcivil.SelectedIndex = -1
        TextBoxnombre.Text = ""
        TextBoxdomicilio.Text = ""
        TextBoxnacimiento.Text = ""
        ComboBoxnac.SelectedIndex = -1
        ComboBoxsex.SelectedIndex = -1

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oSql As String = "INSERT INTO clientes(PIN, Cedula, Estado_Civil, Nombre, Domicilio, Fech_Nacimiento, Nacionalidad, Sexo ) VALUES (" & TextBoxpin.Text & ", " & TextBoxci.Text & ", '" & ComboBoxcivil.SelectedItem & "', '" & TextBoxnombre.Text & "', '" & TextBoxdomicilio.Text & "', '" & TextBoxnacimiento.Text & "', '" & ComboBoxnac.SelectedItem & "', '" & ComboBoxsex.SelectedItem & "')"
        Dim oComando As New MySqlCommand(oSql, oConexion)

        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub ComboBoxcivil_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxcivil.SelectedIndexChanged

    End Sub
End Class