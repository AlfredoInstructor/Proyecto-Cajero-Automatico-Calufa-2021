﻿Imports MySql.Data.MySqlClient
Public Class formATM
    Dim Ingrese_PIN As String
    Dim existe As String



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles retiro.Click
        Dim importe As Double = InputBox("Ingrese el monto")
        Dim Rs As MySqlDataReader

        If existe = 1 Then
            Dim comandoSql As String = "SELECT Saldo, Moneda FROM cuentas WHERE PIN = " & Ingrese_PIN

            Dim Com As New MySqlCommand(comandoSql, oConexion)

            Rs = Com.ExecuteReader()
            Rs.Read()
            Label1.Text = Rs(0)
            Label3.Text = Rs(1)
            Dim saldoactual As Double = Rs(0)
            saldoactual = saldoactual - importe

            Rs.Close()

            'Dim oConexion As New MySqlConnection(cadena)

            Dim ModifSql As String = "UPDATE cuentas SET Saldo = " & saldoactual & " WHERE PIN =" & Ingrese_PIN
            'MsgBox(ModifSql)
            Dim oCommand As New MySqlCommand(ModifSql, oConexion)

            'oConexion.Open()

            oCommand.ExecuteNonQuery()

            Rs = Com.ExecuteReader()
            Rs.Read()
            Label1.Text = Rs(0)

            Rs.Close()
        Else
            MsgBox("Pin Incorrecto")
        End If


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saldo.Click

        If existe = 1 Then
            Dim Rs As MySqlDataReader

            Dim comandoSql As String = "SELECT Saldo, Moneda, Tipo_Cuenta FROM cuentas WHERE PIN = " & Ingrese_PIN

            Dim Com As New MySqlCommand(comandoSql, oConexion)

            Rs = Com.ExecuteReader()
            Rs.Read()
            Label1.Text = Rs(0)
            Label3.Text = Rs(1)
            Label4.Text = Rs(2)

            Rs.Close()
        Else
            MsgBox("Pin Incorrecto")
        End If
 
        



    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deposito.Click
        Dim importe As Double = InputBox("Ingrese el monto")
        Dim Rs As MySqlDataReader
        If existe = 1 Then
            Dim comandoSql As String = "SELECT Saldo, Moneda FROM cuentas WHERE PIN = " & Ingrese_PIN

            Dim Com As New MySqlCommand(comandoSql, oConexion)

            Rs = Com.ExecuteReader()
            Rs.Read()
            Label1.Text = Rs(0)
            Label3.Text = Rs(1)
            Dim saldoactual As Double = Rs(0)
            saldoactual = saldoactual + importe

            Rs.Close()


            Dim ModifSql As String = "UPDATE cuentas SET Saldo = " & saldoactual & " WHERE PIN =" & Ingrese_PIN
            'MsgBox(ModifSql)
            Dim oCommand As New MySqlCommand(ModifSql, oConexion)

            'oConexion.Open()

            oCommand.ExecuteNonQuery()

            Rs = Com.ExecuteReader()
            Rs.Read()
            Label1.Text = Rs(0)

            Rs.Close()
        Else
            MsgBox("Pin Incorrecto")
        End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pin.Click
        Label1.Text = ""
        Label3.Text = ""

        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader

        Ingrese_PIN = InputBox("Ingrese su Numero de PIN")


        SQL2 = "SELECT COUNT(*) FROM cuentas WHERE PIN = " & Ingrese_PIN

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then
            MsgBox("PIN Correcto")
        Else
            MsgBox("PIN Incorrecto")
        End If


    End Sub

    Private Sub formATM_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = ""
        Label3.Text = ""
        Label4.Text = ""
    End Sub

    Private Sub Buttonsalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonsalir.Click
        Me.Close()
    End Sub
End Class