﻿Imports MySql.Data.MySqlClient
Public Class mod_cuentas

    Private Sub mod_cuentas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBoxtipo.Text = ""
        TextBoxfech.Text = ""
        TextBoxmon.Text = ""
        TextBoxsald.Text = ""
        TextBoxsuc.Text = ""
        TextBoxpin.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttontipo.Click
        Me.Close()
    End Sub

    Private Sub Buttonok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonok.Click
        Dim SQL As String
        Dim Rs As MySqlDataReader
        Dim Com As New MySqlCommand
        Dim SQL2 As String
        Dim Rs2 As MySqlDataReader
        Dim existe As String



        SQL2 = "SELECT COUNT(*) FROM cuentas WHERE PIN = " & TextBoxpin.Text

        Dim com2 As New MySqlCommand(SQL2, oConexion)

        Rs2 = com2.ExecuteReader()
        Rs2.Read()

        existe = Rs2(0)
        Rs2.Close()


        If existe = "1" Then

            SQL = "SELECT Tipo_Cuenta, Moneda, Saldo, Fecha_Apertura, N_Sucursal FROM cuentas WHERE PIN = " & TextBoxpin.Text
            Com = New MySqlCommand(SQL, oConexion)

            Rs = Com.ExecuteReader()

            Rs.Read()

            TextBoxtipo.Text = Rs(0)
            TextBoxfech.Text = Rs(3)
            TextBoxmon.Text = Rs(1)
            TextBoxsald.Text = Rs(2)
            TextBoxsuc.Text = Rs(4)

            Rs.Close()
        Else
            MsgBox("PIN Incorrecto")
        End If
    End Sub

    Private Sub Label11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim oSql As String = "UPDATE cuentas SET Tipo_Cuenta = '" & TextBoxtipo.Text & "', " & " Moneda = '" & TextBoxmon.Text & "'," & " Saldo = " & TextBoxsald.Text & ", " & " Fecha_Apertura = '" & TextBoxfech.Text & "', " & " N_Sucursal = " & TextBoxsuc.Text & " " & "WHERE PIN = " & TextBoxpin.Text
        Dim oComando As New MySqlCommand(oSql, oConexion)
        Try
            oComando.ExecuteNonQuery()
            Dim mensaje As String
            mensaje = MsgBox("Se Ingreso Correctamente")
            Me.Close()


        Catch ex As Exception
            MsgBox("Ocurrio el error:" & ex.Message)

        End Try

    End Sub
End Class