﻿Public Class FormMantTransacciones

    Private Sub Buttonal_transaccione_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonalt_transaccione.Click
        FormAltTransacciones.ShowDialog()
    End Sub

    Private Sub Buttonbajatrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonbajatrans.Click
        FormBajaTransacciones.ShowDialog()
    End Sub

    Private Sub Buttonmodtrans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Buttonmodtrans.Click
        FormModTransacciones.ShowDialog()

    End Sub
End Class