﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMantSucursal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMantSucursal))
        Me.Buttonaltsucursal = New System.Windows.Forms.Button()
        Me.Buttonbajasucursal = New System.Windows.Forms.Button()
        Me.Buttonmodsucursal = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Buttonaltsucursal
        '
        Me.Buttonaltsucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonaltsucursal.Location = New System.Drawing.Point(322, 45)
        Me.Buttonaltsucursal.Name = "Buttonaltsucursal"
        Me.Buttonaltsucursal.Size = New System.Drawing.Size(242, 71)
        Me.Buttonaltsucursal.TabIndex = 0
        Me.Buttonaltsucursal.Text = "Alta de Sucursal"
        Me.Buttonaltsucursal.UseVisualStyleBackColor = True
        '
        'Buttonbajasucursal
        '
        Me.Buttonbajasucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonbajasucursal.Location = New System.Drawing.Point(322, 280)
        Me.Buttonbajasucursal.Name = "Buttonbajasucursal"
        Me.Buttonbajasucursal.Size = New System.Drawing.Size(242, 71)
        Me.Buttonbajasucursal.TabIndex = 1
        Me.Buttonbajasucursal.Text = "Baja de Sucursal"
        Me.Buttonbajasucursal.UseVisualStyleBackColor = True
        '
        'Buttonmodsucursal
        '
        Me.Buttonmodsucursal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Buttonmodsucursal.Location = New System.Drawing.Point(322, 510)
        Me.Buttonmodsucursal.Name = "Buttonmodsucursal"
        Me.Buttonmodsucursal.Size = New System.Drawing.Size(242, 71)
        Me.Buttonmodsucursal.TabIndex = 2
        Me.Buttonmodsucursal.Text = "Modificación de Sucursal"
        Me.Buttonmodsucursal.UseVisualStyleBackColor = True
        '
        'FormMantSucursal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 696)
        Me.Controls.Add(Me.Buttonmodsucursal)
        Me.Controls.Add(Me.Buttonbajasucursal)
        Me.Controls.Add(Me.Buttonaltsucursal)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMantSucursal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimiento de Sucursales"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Buttonaltsucursal As System.Windows.Forms.Button
    Friend WithEvents Buttonbajasucursal As System.Windows.Forms.Button
    Friend WithEvents Buttonmodsucursal As System.Windows.Forms.Button
End Class
