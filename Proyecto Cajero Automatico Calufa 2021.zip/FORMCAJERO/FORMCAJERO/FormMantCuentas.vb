﻿Imports MySql.Data.MySqlClient
Public Class mantcuentas

    Private Sub cuentas_alta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cuentas_alta.Click
        alta_cuentas.ShowDialog()
    End Sub

    Private Sub cuentas_baja_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cuentas_baja.Click
        baja_cuentas.ShowDialog()
    End Sub

    Private Sub cuentas_mod_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cuentas_mod.Click
        mod_cuentas.ShowDialog()
    End Sub

    Private Sub mantcuentas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Consultas.Click
        FormGrillCuentas.ShowDialog()
    End Sub
End Class